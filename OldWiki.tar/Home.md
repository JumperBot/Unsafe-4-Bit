<div align="center">

[![Banner.png](https://github.com/JumperBot/Unsafe-4-Bit/blob/6ef49ec496f9fd6120c2088980c6aa754eb08c68/ShortenedBanner.png)](https://github.com/JumperBot/Unsafe-4-Bit/blob/6ef49ec496f9fd6120c2088980c6aa754eb08c68/ShortenedBanner.png)

---

> Unsafe Four Bit | UFB | Unsafe-4-Bit  
> Fast-Paced | Compiled-Interpreted | Dynamically-Typed | Imperative-Procedural  
> Programming Language Built With Rust.

---

UFB reminds you of its ***lower-level counterparts*** as you manage your ***"RAM"***.

The [**`256 items in memory`**](./Z-Others#Memory) is divided into two parts: ROM and non-ROM.

This ***"freedom"*** lets you ***"shoot yourself in the foot"***.

</div>

---

<div align="center">

# ➕ [Installation](https://github.com/JumperBot/Unsafe-4-Bit/wiki/#-installation-%EF%B8%8F) ⬇️ 

### [**`Download The Latest Binary`**](https://github.com/JumperBot/Unsafe-4-Bit/releases/latest)

### [**`Or Clone The Repository And Get Continous Updates`**](https://github.com/JumperBot/Unsafe-4-Bit/wiki/#or-clone-the-repository-and-get-continous-updates):

```bash
git clone https://github.com/JumperBot/Unsafe-4-Bit.git
```

</div>

---

<div align="center">

# 🔧 [Example](https://github.com/JumperBot/Unsafe-4-Bit/wiki/#-example-) 🔨

</div>

```python
// This program creates an endless background of "Hello World"s.

/*
Write "Hello World" to memory index: 38
*/
wvar  38  "Hello World "
// Print the variable residing in memory index: 38
print 38
/* Jump to command no. 0
   if the values in memory indexes 0 and 0 are equal */
je    0  0  0
// Empty out memory index 38 to avoid memory leakage
nvar  38
```
