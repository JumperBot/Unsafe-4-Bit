# Commands

## Default-16

#### 🧱 nop (No Operation) ⬇️
```python
// This will make your program stop for 10 milliseconds!
nop
```
---
#### ✏️ wvar (Write Value) ⬇️
```python
// Write the data "Hello World" into memory index 38
wvar  38  "Hello World"
```
---
#### 🔒 nvar (Null Value) ⬇️
```python
// Remove data in memory index 38
nvar  38
// This avoids theoretical memory leaks
```
---
#### 🔥 trim (Trim Memory) ⬇️
```python
// Trim data in memory index 38 ("Hello World") into "Hello"
// In other words, trim it to only fill in 5 bytes
trim  38  5
```
---
#### 📝 read (Read Console) ⬇️
```python
// Read user input and write it into memory index 38
read  38
```
---
#### 🔊 print (Print Data) ⬇️
```python
// Print data in memory index 38 into the console
print  38
```
---
#### 🙈 math (Do Math) ⬇️
```python
// Add the data in memory index 38 by the data in memory index 39
add  38  39

// Sub the data in memory index 38 by the data in memory index 39
sub  38  39

// Mul the data in memory index 38 by the data in memory index 39
mul  38  39

// Div the data in memory index 38 by the data in memory index 39
div  38  39

// Mod the data in memory index 38 by the data in memory index 39
mod  38  39

// Div the data in memory index 39 by the data in memory index 38
// And then return the left-hand side
// From the decimal's perspective as the result
rmod  38  39


// NOTE: the result will always be stored in the first memory index
```
---
#### 🔀 jump (Jump / Goto) ⬇️
```python
// Jump to command number 0
// Only if the data in memory index 1 is more than the latter
jm   1   2   0

// Jump to command number 0
// Only if the data in memory index 1 is less than the latter
jl   1   2   0

// Jump to command number 0
// Only if the data in memory index 1 is equal to the latter
je   1   2   0

// Jump to command number 0
// Only if the data in memory index 1 is not equal to the latter
jne  1   2   0
```
---
#### 🗃️ file (File Operation) ⬇️
```python
// Write data in memory index 38 into "(???.ufbb DIR)/test.txt"
wfile   38  "test.txt"

// Read data in "(???.ufbb DIR)/ha/ha.txt" into memory index 38
rfile   38  "ha/ha.txt"

// Delete the file / folder "/home/t"
dfile   "/home/t"

// NOTE: wfile will also create the parent folders for you
// NOTE: dfile will also delete the subfolders for you
// NOTE: if the command fails, the program terminates
```
---

### More Info

- `command no` doesn't know what a *"line"* is.

- `-|, \t` can divide between a command and its argument(s).

- Only the compiler will stop you from writing to the `ROM`.

- Manually compiling to a `.ufbb` file is NOT recommended.

---

# Memory

## Memory Table

|Index  |Values   |ROM? |
|:-----:|:-------:|:---:|
|0      |' '      |Yes  |
|1-26   |'A'-'Z'  |Yes  |
|27-36  |'0'-'9'  |Yes  |
|37     |'\n'     |Yes  |
|38-255	|'\u0000' |No   |

## Pointing To Memory

It can be done in several ways as of the moment:

```python
// Point to memory index 38 as an argument
print 38

// Or
print "$038"

// Or inline the data itself
print "Some random stuff"

// Or add the data in memory to even more data
print "Some random stuff: $038"

// Or label the memory index for convinience
label 38 hi
print "${hi}"

// This will definitely not work,
// It will throw a compilation error.
print $038
```

---

# Comments

|Comment|Expanded Meaning		|Multi-line?	|
|:-----:|:-----------------:|:-----------:|
|//			|Normal Comment			|No						|
|/\*\*/	|Multi-line Comment	|Yes					|

---

# Example

```python
// This program creates an endless background of "Hello World"s.

/*
Write "Hello World" to memory index: 38
*/
wvar  38  "Hello World "
// Print the value residing in memory index: 38
print 38
/* Jump to command no. 0
   if the values in memory indexes 0 and 0 are equal */
je    0  0  0
// Empty out memory index 38 to avoid memory leakage
nvar  38
```
